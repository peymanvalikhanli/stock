<p dir="rtl"><strong><a href="https://github.com/hosseinizadeh/AdminLTE_Persian/">AdminLTE_Persian</a></strong> یک قالب کاملا رسپانسیو است که برای ایجاد پنل مدیریت زیبا ایجاد شده است. این قالب بر اساس فریمورک <a href="https://getbootstrap.com">Bootstrap 3</a> پیاده سازی شده و کاملا قابل شخصی سازی است.</p>

<p dir="rtl"><a href="http://hosseinizadeh.ir/adminlte">پیش نمایش</a></p>


!["AdminLTE_persian Presentation"](http://hosseinizadeh.ir/blog/wp-content/uploads/2017/07/Screen-Shot-%DB%B1%DB%B3%DB%B9%DB%B6-%DB%B0%DB%B5-%DB%B0%DB%B3-at-%DB%B1%DB%B7.%DB%B5%DB%B1.%DB%B2%DB%B7.jpg "AdminLTE_persian Presentation")

<h2 dir="rtl">نصب و راه اندازی</h2>

```
git clone https://github.com/hosseinizadeh/AdminLTE_Persian.git
```

<h2 dir="rtl">همکاری در توسعه</h2>

<ul dir="rtl">
  <li>ابتدا از پروژه فعلی Fork بگیرید</li>
  <li>پروژه Fork شده را بر روی سیستم خودتان Clone کنید</li>
  <li>یک Branch جدید بر روی سیستم خودتان ایجاد کنید</li>
  <li>تغییرات خودتان را اعمال کنید</li>
  <li>در نهایت درخواست Pull Request برای ما ارسال کنید</li>
</ul>
